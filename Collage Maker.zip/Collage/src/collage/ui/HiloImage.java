// Christian Ricardo Solís Cortés
// A01063685
// Collage of JPG & PNG images using Threads
// Programming Languages

package collage.ui;

import collage.ui.CollageUI;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.swing.JComponent;

public class HiloImage extends JComponent implements Runnable
{
    // Instancia principal (única)
    private CollageUI principal;
    private File fileImage;
    
    public HiloImage(CollageUI principal, File file)
    {
        this.fileImage = file;
        this.principal = principal;
    }
    
    // Método principal del thread que optiene una región aleatoria
    // de las imagenes
    @Override
    public void run()
    {
        int x=0,y=0;
        BufferedImage img;
        
        try
        {
            // Lectura de la imagen cargada
            img = ImageIO.read(new FileInputStream(fileImage));
            
            // Se especifican que optendremos 10 fragmentos de la imagen
            for(int index=0;index<10;index++)
            {
                x = new Random().nextInt(img.getWidth());
                y = new Random().nextInt(img.getHeight());
                
                if(x>0&&y>1)
                {
                    Image imagePart1;
                    // Se especifica una region aleatoria a capturar
                    imagePart1 = createImage(
                     new FilteredImageSource(img.getSource(),
                     new CropImageFilter(y,x,x,y)));

                    // Se guarda región previa de la imagen en el arreglo 
                    // de imagenes principal
                    principal.getArrayListImage().add(imagePart1);
                }
            }
        }
        catch (FileNotFoundException e)
        {
        }
        catch (Exception e)
        {
        }
    }
}

// Christian Ricardo Solís Cortés
// A01063685
// Collage of JPG & PNG images using Threads
// Programming Languages