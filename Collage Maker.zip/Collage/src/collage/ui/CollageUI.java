// Christian Ricardo Solís Cortés
// A01063685
// Collage of JPG & PNG images using Threads
// Programming Languages

package collage.ui;

import com.leyer.JKActiveSyntethica;
import com.leyer.JKList;
import com.leyer.JKMenu;
import com.leyer.JKMenuBar;
import de.javasoft.plaf.synthetica.SyntheticaBlackEyeLookAndFeel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.CropImageFilter;
import java.awt.image.FilteredImageSource;
import java.io.File;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javax.imageio.ImageIO;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.UIManager;
import javax.swing.filechooser.FileNameExtensionFilter;
import org.jdesktop.swingx.JXBusyLabel;
import org.jdesktop.swingx.JXImageView;


public class CollageUI extends javax.swing.JFrame
{
    
    // Creación de UI de la forma
    // Variable que lleva el control de los segundos pasados
    private int contadorSegundos=0;
    // Variable que indica el tiempo maximo a esperar para finalizar el collage
    private int tiempoMaxDeEspera=15;
    
    // Lista de las imagenes que se van agregando en la parte visual
    private JKList list;
    
    // Selector de Archivos
    private JFileChooser chooser= new JFileChooser();
    
    public static int x=950; 
    public static int y=500;
    
    // Visualizador
    private JXImageView visor;
     
    // Etiqueta de carga
    private final JXBusyLabel busyLabel;
    
    // Inicialización de componentes de la UI
    public CollageUI()
    {
        initComponents();
        JKMenuBar jKMenuBar = new JKMenuBar(100, 240, Color.BLUE);
        setJMenuBar(jKMenuBar);
        JMenu mx=new JMenu("  ");
        jKMenuBar.add(mx);
        setTitle("Collage");
        list=new JKList();
        // list.setBackground(Color.LIGHT_GRAY);
        list.setFont(new java.awt.Font("DialogInput", 1, 13)); 
        jScrollPane1.setViewportView(list);
        
        visor=new JXImageView();
        visor.setVisible(false);
        visor.setLayout(null);
                
        setResizable(false);
        jPanel3.add(visor,BorderLayout.CENTER);
        setSize(1200,560);
        jPanel2.setOpaque(false);
       
        busyLabel=new JXBusyLabel(new Dimension(200,200));
        busyLabel.setBusy(true);
        busyLabel.setVisible(false);
        jPanel3.add(busyLabel,BorderLayout.WEST);
        busyLabel.getBusyPainter().setBaseColor(Color.BLUE);
        
        // Botón de exportar imagen
        JPopupMenu jPopupMenu=new JPopupMenu();
        JMenuItem menuItem=new JMenuItem("  Exportar Imagen  ");
        menuItem.addActionListener(new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent e)
            {
              exportarImagen();
            }
        });
        jPopupMenu.add(menuItem);
        visor.setComponentPopupMenu(jPopupMenu);
        
        setLocationRelativeTo(null);
    }
    
    // Método que convierte imagen seleccionada en BufferedImage
    // para su procesamiento
    public static BufferedImage toBufferedImage(Image img)
    {
        if (img instanceof BufferedImage)
        {
            return (BufferedImage) img;
        }
        
        BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
        Graphics2D bGr = bimage.createGraphics();
        bGr.drawImage(img, 0, 0, null);
        bGr.dispose();
        return bimage;
    }
    
    // Capturar la imagen de un componente
    public BufferedImage getScreenShot(Component component)
    {
       BufferedImage image = new BufferedImage
       (
         component.getWidth()-4,
         component.getHeight(),
         BufferedImage.TYPE_INT_RGB
       );
       component.paint( image.getGraphics() ); 
       return image;
    }
    
    // Método que exporta la imagen
    public void exportarImagen()
    {
        // Se obtiene la imagen y crea nueva para el Collage
        Image x= visor.createImage(visor.getWidth(), visor.getHeight());
        try
        {
            JFileChooser fileChooser= new JFileChooser();
            fileChooser.setSelectedFile(new File(".jpg"));
            int n = fileChooser.showSaveDialog(getInstance());
            if(n==JFileChooser.APPROVE_OPTION)
            {
                // Se crea la imagen y guardamos en la raiz
                BufferedImage z = getScreenShot(visor);
                File l=fileChooser.getSelectedFile();
                // Se añade extensión .jpg al Collage y se escribe 
                ImageIO.write(z,"jpg",l);
                // Se abre el archivo al finalizar
                Desktop.getDesktop().open(l);
            }
        }
        
        catch(Exception ex)
        {
           ex.printStackTrace();
        }
    }
    
    public ArrayList<File> getArrayListPathImages()
    {
            return arrayListPathImages;
    }
    
    public ArrayList<Image> getArrayListImage()
    {
        return arrayListImage;
    }
	
    // Método para retornar esta clase
    public CollageUI getInstance()
    {
        return this;
    }
    
    // ArrayList de los path de las imagenes seleccionadas
    private ArrayList<File> arrayListPathImages = new ArrayList<>();

    // ArrayList de las imagenes recortadas
    private ArrayList<Image> arrayListImage=new ArrayList<>();

    // Conteo de la cantidad de imagenes seleccionadas
    private int contadorArchivos=1;
	
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton2 = new javax.swing.JButton();
        progressBar = new javax.swing.JProgressBar();
        jButton3 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/collage/resource/33.png"))); // NOI18N
        jButton1.setText("Seleccionar Individual");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel1.setLayout(new java.awt.GridLayout(1, 0));

        jScrollPane1.setBackground(new java.awt.Color(204, 204, 204));
        jScrollPane1.setFont(new java.awt.Font("DialogInput", 1, 18)); // NOI18N
        jPanel1.add(jScrollPane1);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Nro. de Archivos:");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 204));
        jLabel2.setText("0");

        jButton2.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/collage/resource/41.png"))); // NOI18N
        jButton2.setText("Crear Collage");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        progressBar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        progressBar.setOpaque(true);
        progressBar.setStringPainted(true);

        jButton3.setFont(new java.awt.Font("Eras Demi ITC", 1, 18)); // NOI18N
        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/collage/resource/A1-close.png"))); // NOI18N
        jButton3.setText("Salir");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/collage/resource/export.png"))); // NOI18N
        jButton4.setText("Exportar");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jButton5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/collage/resource/33.png"))); // NOI18N
        jButton5.setText("Seleccionar Carpeta");
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(progressBar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, 101, Short.MAX_VALUE))
            .addComponent(jSeparator1)
            .addComponent(jButton5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jButton5, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 5, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(progressBar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jSplitPane1.setLeftComponent(jPanel2);

        jPanel3.setLayout(new java.awt.BorderLayout());
        jSplitPane1.setRightComponent(jPanel3);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 1177, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSplitPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Método al seleccionar Individual
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        // Filtro que acepta sólo imagenes 
        FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpg", "png");
        // Set del filtro anterior
        chooser.setFileFilter(filter);
        // Abrir selector
	int n=chooser.showOpenDialog(getInstance());
        // Si se seleccionan la imagen
	if(n==JFileChooser.APPROVE_OPTION)
        {
            //optenemos la imagen
            File f = chooser.getSelectedFile();
            int xx= new ImageIcon(f.getAbsolutePath()).getIconWidth();
            // Si el ancho es mayor a 1024
            if(xx>=1024)
            {
                // Warning de imagen no soportada
                JOptionPane.showMessageDialog(getInstance(), "Imagen no Soportada, no pueden ser imágenes mayores a 1024","",JOptionPane.WARNING_MESSAGE);
                return;
            }
           
            // Instancia del framework
            // Reducción del tamaño de la imagen
            Image x= Toolkit.getDefaultToolkit().createImage(f.getAbsolutePath()).getScaledInstance(50, 50, 50);
            // Se agrega el nombre del archivo, junto a la imagen recortada
            list.addItem(f.getName(),new ImageIcon(x));
            // Se guarda la ruta en el arraylist
            arrayListPathImages.add(f);

            // Thread que toma la imagen
            // y la divide en "pedazos" o multiples imagenes
            // Manda llamar la clase HiloImage que lee las imagenes
            // y las cortan en trozos
            HiloImage hiloImage=new HiloImage(getInstance(),f);
            new Thread(hiloImage).start();

            // Contador de archivos en el visualizador
            jLabel2.setText(""+contadorArchivos);
            jLabel2.repaint();

            // Incremento del contador de archivos
            contadorArchivos++;
	}
			
    }//GEN-LAST:event_jButton1ActionPerformed

    // Inicio al presionar Crear Collage
    public void iniciar()
    {
        // Número de componentes del panel
        for(int index=0;index< visor.getComponentCount();index++)
        {
            visor.remove(index);
        }
        
        // Remover componentes 
        visor.removeAll();
        visor.revalidate();
        visor.repaint();
        running=true;
        visor.setVisible(false);
        
        // Estado de construcción
        progressBar.setString("Construyendo Imagen...");
        progressBar.setIndeterminate(true);
        // Inicio de método load 
        load();
        jButton2.setEnabled(false);
        busyLabel.setVisible(true);
    }
    
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
              iniciar();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
       exportarImagen();
    }//GEN-LAST:event_jButton4ActionPerformed

    // ActionPerformed de botón Seleccionar carpeta
    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
       // Directorio actual
       chooser.setCurrentDirectory(new java.io.File("."));
       chooser.setDialogTitle("Carpeta");
       // Permitir seleccionar SÓLO carpetas
       chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
       chooser.setAcceptAllFileFilterUsed(false);
       // Selector abierto
       int n=chooser.showOpenDialog(getInstance());
       if(n==JFileChooser.APPROVE_OPTION)
       {
           // Instancia de archivos
           File  directory=chooser.getSelectedFile();
           File[] listFiles = directory.listFiles();
           
           for(int index=0;index<listFiles.length;index++)
           {
               // Se obtiene la imagen
               File f = listFiles[index];
               // Si las extensiones de las imagenes son jpg, jpeg, png
               if(f.getName().endsWith("jpg")||f.getName().endsWith("jpeg")||f.getName().endsWith("png")||f.getName().endsWith("PNG")
                        ||f.getName().endsWith("JPG"))
               {
                   // Objeto que coloca imagenes
                   // Obtener tamaño de imagen
                   int xx = new ImageIcon(f.getAbsolutePath()).getIconWidth();
                   // Si el ancho es mayor a 1024
                   if(xx>=1024)
                   {
                       // Warning de imagen no soportada
                       JOptionPane.showMessageDialog(getInstance(), "Imagen no soportada, no pueden ser imágenes mayores a 1024","",JOptionPane.WARNING_MESSAGE);
                       continue;
                   }
                   
                   // Reducción del tamaño de la imagen
                   Image x= Toolkit.getDefaultToolkit().createImage(f.getAbsolutePath()).getScaledInstance(50, 50, 50);
                   
                   // Se agrega el nombre del archivo, junto a la imagen recortada
                   list.addItem(f.getName(),new ImageIcon(x));
                   // Se guarda la ruta en el arraylist
                   arrayListPathImages.add(f);

                   // Thread que toma la imagen
                   // y la divide en "pedazos" o multiples imagenes 
                   HiloImage hiloImage = new HiloImage(getInstance(),f);
                   // Comienzo del thread
                   new Thread(hiloImage).start();

                   // Contador de archivos en el visualizador
                   jLabel2.setText(""+contadorArchivos);
                   jLabel2.repaint();

                   // Si son más de 10 archivos se detiene
                   if(contadorArchivos==10)
                   {
                       break;
                   }
                  
                   // Incremento del contador de archivos
                   contadorArchivos++;
                }
            }
	}
    }//GEN-LAST:event_jButton5ActionPerformed

    // ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    // Clase main que crea thread inicial
    
    public static void main(String args[])
    {
        try
        {
            // Diseño de interfaz con librería Synthetica
            new JKActiveSyntethica();
            UIManager.setLookAndFeel(new SyntheticaBlackEyeLookAndFeel());
 
            // Nuevo task de thread inicial
            java.awt.EventQueue.invokeLater(new Runnable()
            {
                public void run()
                {
                    new CollageUI().setVisible(true);
                }
            });
        } 
        catch (Exception ex)
        {
        }
    }
    
    // Variables de la forma
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JProgressBar progressBar;
    // End of variables declaration//GEN-END:variables

   // Variable para controlar el estado de los hilos en ejecucion que cargan las imagenes
   // en la parte visual
   private boolean running=true;
   
   // Thread que agrega las imagenes cortadas en el panel visualizador
   // de manera aleatoria
   class threadAddImages extends Thread
   {
        @Override
        public void run()
        {
            // Mientras running sea true
            while(running)
            {
                try
                {
                   JLabel label1=new JLabel();
                   // Se obtiene una imagen aleatoria de las imagenes cortadas
		   label1.setIcon(new ImageIcon(arrayListImage.get(new Random().nextInt(arrayListImage.size()))));
                   // Ancho y alto aleatorio
		   int b13 = new Random().nextInt(getWidth());
                   int b24 = new Random().nextInt(getHeight());	
                   // Posición y tamaño del GUI aleatoria
		   label1.setBounds(b13,b24,90,90);
                   // Añadir label al visualizador
                   visor.add(label1);
                }
                catch(Exception e)
                {
                    return;
                }
                
                try
                {
                   JLabel label1=new JLabel();
                   // Se obtiene una imagen aleatoria de las imagenes cortadas
		   label1.setIcon(new ImageIcon(arrayListImage.get(new Random().nextInt(arrayListImage.size()))));
                   // Ancho y alto aleatorio
		   int b13=new Random().nextInt(getWidth());
                   int b24=new Random().nextInt(getHeight());
                   // Posición y tamaño del GUI aleatoria
		   label1.setBounds(b13,0,90,90);
                   // Añadir label al visualizador
                   visor.add(label1);
                }
                catch(Exception e)
                {
                    return;
                }	
               
                try
                {
                   JLabel label1=new JLabel();
                   // Se obtiene una imagen aleatoria de las imagenes cortadas
		   label1.setIcon(new ImageIcon(arrayListImage.get(new Random().nextInt(arrayListImage.size()))));
                   // Ancho y alto aleatorio
		   int b13=new Random().nextInt(getWidth());
                   int b24=new Random().nextInt(getHeight());	
                   // Posición y tamaño del GUI aleatoria
		   label1.setBounds(0,b24,90,90);
                   // Añadir label al visualizador
                   visor.add(label1);
                }
                catch(Exception e)
                {
                    return;
                }	
            }
        }
    }
    
    // Crea 2 hilos para rellenar el visor de imagen
    public void load()
    {
        // 2 threads para agregar las imágenes aleatoriamente
        new threadAddImages().start();
        new threadAddImages().start();
       
        // Timer barra de progreso
        final  Timer timer=new Timer();
        TimerTask timerTask=new TimerTask()
        {
            @Override
            public void run()
            {
                contadorSegundos++;
                // Si se llega al tiempo máximo
                if(contadorSegundos==tiempoMaxDeEspera)
                {
                    busyLabel.setVisible(false);
                    visor.setVisible(true);
                    visor.repaint();
                    running = false;
                    jPanel1.validate();

                    // Reinicio de barra de progreso
                    progressBar.setValue(0);
                    progressBar.setIndeterminate(false);
                    progressBar.setString("Completado");
                    progressBar.validate();;

                    // Limpieza de arraylist con imagenes
                    arrayListImage.clear();
                    arrayListPathImages.clear();

                    // Botón de crear collage activo
                    jButton2.setEnabled(true);
                    DefaultListModel defaultListModel=(DefaultListModel)list.getModel();
                    defaultListModel.clear();

                    jLabel2.setText("0");
                    // Reinicia contador de archivos
                    contadorArchivos=1;
                    // Contador visual actualizado

                    // Se cancela el timer pues ha finalizado
                    timer.cancel();
                    contadorSegundos=0;
                }
            }
        };
        // Inicio de timer
        timer.schedule(timerTask, 0,1000);
    }
}

// Christian Ricardo Solís Cortés
// A01063685
// Collage of JPG & PNG images using Threads
// Programming Languages